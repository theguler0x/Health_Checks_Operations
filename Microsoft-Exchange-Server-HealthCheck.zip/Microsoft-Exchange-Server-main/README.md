# Microsoft-Exchange Server Health Checker
Exchange-Healty-Checker Notes.

Exchange Server HealthChecker.ps1 scripti ile ortamınızda bulunan Exchange sunucular hakkında detaylı bilgi edinebilir, sunucularını üzerinde bulunan hataları kontrol edebilir, performans sorunlarına göz atabilirsiniz. Ayrıca Exchange sunucuların zorunlu olarak gerek duyduğu tüm güvenlik güncelleştirme yamalarınının (CVE-202x.xxx) sisteminizde yüklü olup olmadığı hakkında detaylı bilgi alabilirsiniz.

https://farukguler.com/2022/11/17/exchange-health-check/

With the Exchange Server HealthChecker.ps1 script, you can get detailed information about the Exchange servers in your environment, check the errors on the servers, and take a look at the performance problems. You can also get detailed information about whether all security update patches (CVE-202x.xxx) required by Exchange servers are installed on your system.

https://farukguler.com/2022/11/17/exchange-health-check/
